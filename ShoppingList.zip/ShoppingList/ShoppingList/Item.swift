//
//  Item.swift
//  ShoppingList
//
//  Created by admin on 7/20/21.
//

import Foundation

class Item {
    var name: String!
    var quantity: Int!
    var price: Int!
    
    init(name: String, quantity: Int, price: Int)
        {self.name = name
        self.quantity = quantity
        self.price = price
    }
}
