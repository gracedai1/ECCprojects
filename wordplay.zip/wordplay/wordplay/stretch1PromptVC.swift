//
//  stretch1PromptVC.swift
//  wordplay
//
//  Created by admin on 7/20/21.
//

import UIKit

class stretch1PromptVC: UIViewController {

    @IBOutlet var stretch1NounTF: UITextField!
    @IBOutlet var stretch1AdjTF: UITextField!
    @IBOutlet var stretch1VerbTF: UITextField!
    @IBOutlet var stretch1GenButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! stretch1GenerateVC
        vc.noun = stretch1NounTF.text!
        vc.adj = stretch1AdjTF.text!
        vc.verb = stretch1VerbTF.text!
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
