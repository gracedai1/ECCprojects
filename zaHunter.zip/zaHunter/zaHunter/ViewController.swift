//
//  ViewController.swift
//  zaHunter
//
//  Created by admin on 8/5/21.
//

import CoreLocation
import MapKit
import UIKit

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var map: MKMapView!
    
    let manager = CLLocationManager()
    let annotation = MKPointAnnotation()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        /*let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D (latitude: 37.80141181514283, longitude: -122.41942370568496)
        annotation.title = "Za Pizza"
        annotation.subtitle = "pizza"
        map.addAnnotation(annotation)

        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = CLLocationCoordinate2D (latitude: 37.77313436611127, longitude: -122.40645955596348)
        annotation2.title = "Pizza Squared"
        annotation2.subtitle = "pizza"
        map.addAnnotation(annotation2)*/
        
        let region = MKCoordinateRegion (center: annotation.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
        map.setRegion(region, animated: true)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        manager.requestWhenInUseAuthorization()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest //battery
        manager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            manager.stopUpdatingLocation()
            
            render(location)
        }
    }
    
    func render (_ location: CLLocation) {
        
        let coordinate = CLLocationCoordinate2D (latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        
        let region = MKCoordinateRegion(center: coordinate, span: span)
        map.setRegion(region, animated: true)
    }
 
}


