//
//  ViewController.swift
//  finalGradeCalculator
//
//  Created by admin on 7/12/21.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet var myButton: UIButton!
    @IBOutlet var text: UITextField!
    @IBOutlet var text2: UITextField!
    @IBOutlet var neededgradelabel: UILabel!
    @IBOutlet var currentgradelabel: UILabel!
    @IBOutlet var desiredgradelabel: UILabel!
    @IBOutlet var percentfinallabel: UILabel!
    @IBOutlet var finalweightTextField: UITextField!
    
    @IBOutlet var percentsign: UILabel!
    
    @IBOutlet var desiredSC: UISegmentedControl!
    @IBOutlet var pickerview: UIPickerView!
    
    var pickerData: [String] = [String]()

    //var neededGrade:Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //self.picker.delegate = self
        //self.picker.dataSource = self
        self.pickerview.delegate = self
        self.pickerview.dataSource = self
        
        pickerData = ["A","B","C", "D"]
    }
    
    //func calculateGrade (currentGrade = Int, desiredGrade = Int)
    
    //@IBAction func textfield1(_ sender: UITextField) {let currentGrade = Int(text.text!)}
    
    @IBAction func buttonPressed(_ sender: UIButton)  {
        
        view.endEditing(true);
        let currentGrade = Double(text.text!)!
        var desiredGrade = Double(text2.text!)!
        var finalWeight = Double(finalweightTextField.text!)!
        
        var neededGrade = (100 * desiredGrade - (100 - finalWeight) * currentGrade) / finalWeight
            //(desiredGrade - currentGrade) / (finalWeight / 100)
            
        neededgradelabel.text = "You will need a final grade of \(neededGrade) to get your desired grade."
        
        if neededGrade < 100 {view.backgroundColor = .green}
        else if neededGrade > 100 {view.backgroundColor = .red;
            neededgradelabel.text = "You will need a final grade of \(neededGrade) to get your desired grade. You should ask your teacher for extra credit."}
    }
    
    @IBAction func gradesegments(_ sender: UISegmentedControl) {
       
        
        switch desiredSC.selectedSegmentIndex {
        case 0: text2.text = "90"
        case 1: text2.text = "80"
        case 2: text2.text = "70"
        case 3: text2.text = "60"
        default: break
        }
    }
  
//pickerview
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch row {
        case 0: text2.text = "90"
        case 1: text2.text = "80"
        case 2: text2.text = "70"
        case 3: text2.text = "60"
        default: break
        }
        
    }
    /*self.picker.delegate = self
    self.picker.dataSource = self*/
        
    
   // @IBAction func desiredgradetext(_ sender: Any) -> Int {}
    ///*, currentGrade: Int, finalWeight: Int*/
}
    

