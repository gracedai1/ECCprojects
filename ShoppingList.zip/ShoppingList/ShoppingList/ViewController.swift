//
//  ViewController.swift
//  ShoppingList
//
//  Created by admin on 7/20/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
        
    
    @IBOutlet var tableView: UITableView!
  
    
    @IBOutlet var composeNew: UIBarButtonItem!
    
    var items : [Item] = []
    
    //newitems
    var newName:String = ""
    var newPrice:String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let item1 = Item(name: "Milk", quantity: 2, price: 5)
        let item2 = Item(name: "Eggs", quantity: 16, price: 3)
        let item3 = Item(name: "Bacon", quantity: 16, price: 3)
        
        items = [item1,item2,item3]
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "cellID") {
            let currentItem = items[indexPath.row]
            
            cell.textLabel!.text = currentItem.name
            cell.detailTextLabel?.text =
                "Quantity: \(currentItem.quantity!)"
            return cell
        }
        
        return UITableViewCell()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let indexPath = tableView.indexPathForSelectedRow {
            let item = items[indexPath.row]
            let vc = segue.destination as! DetailViewController
            vc.item = item
        }
    }
    
    //add new items into array code
    /*let newItem = Item (name: newName, price: Int(newPrice)!)
    items.append (newItem)
    tableView.reloadData()*/
    

}

