//
//  starViewController.swift
//  intergalacticTraveler
//
//  Created by admin on 7/22/21.
//

import UIKit

class starViewController: UIViewController {

    @IBOutlet var starImage: UIImageView!
    
    // This is the Bool we will be set when we're passed a true/false from the 1st ViewController
        var isGoingToRedDwarfPassed : Bool!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let red1 = UIImage (named: "RedDwarf1")
        let red2 = UIImage (named: "RedDwarf2")
        let red3 = UIImage (named: "RedDwarf3")
        let blue1 = UIImage (named: "BlueDwarf1")
        let blue2 = UIImage (named: "BlueDwarf2")
        let blue3 = UIImage (named: "BlueDwarf3")
        
        let redArray = [red1, red2, red3]
        let blueArray = [blue1, blue2, blue3]

        let randomNumber = Int.random(in: 0..<3)
        
        if isGoingToRedDwarfPassed == true {
            starImage.image = redArray[randomNumber]
        } else if isGoingToRedDwarfPassed == false {
            starImage.image = blueArray[randomNumber]
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
