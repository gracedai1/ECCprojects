//
//  stretch1GenerateVC.swift
//  wordplay
//
//  Created by admin on 7/20/21.
//

import UIKit

class stretch1GenerateVC: UIViewController {

    @IBOutlet var stretch1sentence: UILabel!
    var noun:String = ""
    var adj:String = ""
    var verb:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        stretch1sentence.text = "Your \(adj) \(noun) will be \(verb)ing soon."
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
