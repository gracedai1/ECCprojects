//
//  ViewController.swift
//  modalSeguesAssessment
//
//  Created by admin on 7/22/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var segueButton: UIButton!
    @IBOutlet var wordTF: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! secondViewController
        vc.word = wordTF.text!
    }

}

