//
//  ViewController.swift
//  intergalacticTraveler
//
//  Created by admin on 7/22/21.
//

import UIKit

class ViewController: UIViewController {
   
    var isGoingTobeRedDwarf : Bool!
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func reddwarfBtnTapped(_ sender: UIButton) {
        isGoingTobeRedDwarf = true
    }
    
    @IBAction func bluedwarfBtnTapped(_ sender: UIButton) {
        isGoingTobeRedDwarf = false
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! starViewController
        vc.isGoingToRedDwarfPassed = isGoingTobeRedDwarf
        
    }
    
}

