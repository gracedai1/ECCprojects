//
//  ViewController.swift
//  wordplay
//
//  Created by admin on 7/20/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var mvplabel1: UILabel!
    @IBOutlet var mvpTF: UITextField!
    @IBOutlet var mvpbutton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func mvpbuttonclicked(_ sender: Any) {
       
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! mvpVC
        //let unclePlace = mvpTF.text!
        vc.unclePlace = mvpTF.text!
        
        //segue.destination.navigationItem.title = mvplabel1.text
    }

}

