//
//  ViewController.swift
//  codeAssessOperators
//
//  Created by admin on 7/15/21.
//

import UIKit

class ViewController: UIViewController {
//mvp
    @IBOutlet var numberOne: UITextField!
    @IBOutlet var numberTwo: UITextField!
    @IBOutlet var textfield3: UITextField!
    @IBOutlet var textfield4: UITextField!
    @IBOutlet var textfield5: UITextField!
    @IBOutlet var textfield6: UITextField!
    @IBOutlet var textfield7: UITextField!
    @IBOutlet var textfield8: UITextField!
    @IBOutlet var textfield9: UITextField!
    @IBOutlet var textfield10: UITextField!
    @IBOutlet var textfield11: UITextField!
    @IBOutlet var textfield12: UITextField!
    
    @IBOutlet var labelequalto: UILabel!
    @IBOutlet var labelnotequalto: UILabel!
    @IBOutlet var labelgreater: UILabel!
    @IBOutlet var labellessthan: UILabel!
    @IBOutlet var labelgreatequal: UILabel!
    @IBOutlet var labellessequal: UILabel!
    
    @IBOutlet var mvpbutton: UIButton!
//stretch 1
    @IBOutlet var numTicketsTF: UITextField!
    @IBOutlet var purchasedPackagesLabel: UILabel!
    @IBOutlet var individTicketsLabel: UILabel!
    
    @IBOutlet var stretch1button: UIButton!
    
    
    
    //@IBAction func number1input(_ sender: Any) {}
    
   // @IBAction func number2input(_ sender: UITextField) {
     //   let number2 = Int(numberTwo.text!)!}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
//mvp button code
    @IBAction func checkmvp(_ sender: Any) {
        
        let number1 = Int(numberOne.text!)!
        let number2 = Int(numberTwo.text!)!
        let number3 = Int(textfield3.text!)!
        let number4 = Int(textfield4.text!)!
        let number5 = Int(textfield5.text!)!
        let number6 = Int(textfield6.text!)!
        let number7 = Int(textfield7.text!)!
        let number8 = Int(textfield8.text!)!
        let number9 = Int(textfield9.text!)!
        let number10 = Int(textfield10.text!)!
        let number11 = Int(textfield11.text!)!
        let number12 = Int(textfield12.text!)!


        if number1 == number2 {labelequalto.text = "evaluates to True"}
        else if number1 != number2{labelequalto.text = "evaluates to False"}
        
        if number3 != number4 {labelnotequalto.text = "evaluates to True"}
        else {labelnotequalto.text = "evaluates to False"}
        
        if number5 > number6 {labelgreater.text = "evaluates to True"}
        else {labelgreater.text = "evaluates to False"}
        
        if number7 < number8 {labellessthan.text = "evaluates to True"}
        else {labellessthan.text = "evaluates to False"}

        if number9 >= number10 {labelgreatequal.text = "evaluates to True"}
        else {labelgreatequal.text = "evaluates to False"}

        if number11 <= number12 {labellessequal.text = "evaluates to True"}
        else {labellessequal.text = "evaluates to False"}
    }
    
//stretch 1 and 2 code
    @IBAction func stretch1button(_ sender: Any) {
        var tickets = Int(numTicketsTF.text!)!
        
        var purchasedPackages = tickets / 4
        var individTix = tickets - 4 * (purchasedPackages)
        
        purchasedPackagesLabel.text = "Buy \(purchasedPackages) packages."
        individTicketsLabel.text = "Buy \(individTix) single tickets."
    }
   
  /*  @IBAction func swiperight (_ sender: UISwipeGestureRecognizer)
    {
        if sender.direction == UISwipeGestureRecognizer.right
        {var tickets = tickets + 1}
        
        
        
    }*/
    //stretch 2 code
    

    
    
    
}

