//
//  newItemVC.swift
//  ShoppingList
//
//  Created by admin on 7/23/21.
//

import UIKit

class newItemVC: UIViewController {

    @IBOutlet var newItemNameTF: UITextField!
    @IBOutlet var newItemPriceTF: UITextField!
    
    @IBOutlet var savenewBtn: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    //segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let newitemssegue = segue.destination as! ViewController
        newitemssegue.newName = newItemNameTF.text!
        newitemssegue.newPrice = newItemPriceTF.text!
    }
    
    //newitem button
    
    @IBAction func savenewitem(_ sender: Any) {
        
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
