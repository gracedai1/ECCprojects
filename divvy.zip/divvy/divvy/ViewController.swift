//
//  ViewController.swift
//  divvy
//
//  Created by admin on 8/10/21.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var map: MKMapView!
    
    let manager = CLLocationManager()
    let annotation = MKPointAnnotation()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //api
        let url = "https://data.cityofchicago.org/resource/eq45-8inv.json"
        getData (from: url)
        
//annotations
        let annotation = MKPointAnnotation()
       // annotation.coordinate = CLLocationCoordinate2D 
        map.addAnnotation(annotation)
        
        let region = MKCoordinateRegion (center: annotation.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
        map.setRegion(region, animated: true)

    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        manager.requestWhenInUseAuthorization()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest //battery
        manager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            manager.stopUpdatingLocation()
            
            render(location)
        }
    }
    
    func render (_ location: CLLocation) {
        
        let coordinate = CLLocationCoordinate2D (latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        
        let region = MKCoordinateRegion(center: coordinate, span: span)
        map.setRegion(region, animated: true)
    }
    
    
    //api
    private func getData(from url: String) {
        
        let task = URLSession.shared.dataTask(with: URL(string:url)!, completionHandler: { data, response, error in
            
            guard let data = data, error == nil else {
                print ("something went wrong")
                return
            }
            //have data
            var result : Response?
            do {
                result = try JSONDecoder().decode(Response.self, from: data)
            }
            catch {
                print ("failed to convert \(error.localizedDescription)")
            }
            guard let json = result else {
                return
            }
            print ("json.status")
            
    })
        
    task.resume()
}


struct Response: Codable {
    let results : Myresult
}

struct Myresult: Codable {
    
}
    
}
