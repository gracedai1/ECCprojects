//
//  mvpVC.swift
//  wordplay
//
//  Created by admin on 7/20/21.
//

import UIKit

class mvpVC: UIViewController {

    //mvp
    @IBOutlet var mvpNewLabel: UILabel!
    @IBOutlet var nextButtonmvp: UIButton!
    var unclePlace: String = ""
        
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        mvpNewLabel.text = "My uncle wants to go to the \(unclePlace)."

    }
    
    /*override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! stretch1PromptVC
        //let unclePlace = mvpTF.text!
        //vc.unclePlace = mvpTF.text!
    }*/
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
